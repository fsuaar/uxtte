module Spree
  module Addresses
    class Find < ::Spree::BaseFinder
    end
  end
end
