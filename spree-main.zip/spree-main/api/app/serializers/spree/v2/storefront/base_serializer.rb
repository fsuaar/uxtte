require 'active_support/cache'

module Spree
  module V2
    module Storefront
      class BaseSerializer < ::Spree::Api::V2::BaseSerializer
      end
    end
  end
end
