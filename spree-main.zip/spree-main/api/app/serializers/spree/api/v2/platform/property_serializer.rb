module Spree
  module Api
    module V2
      module Platform
        class PropertySerializer < BaseSerializer
          include ResourceSerializerConcern
        end
      end
    end
  end
end
