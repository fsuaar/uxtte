module Spree
  module Api
    module V2
      module Platform
        class ShippingCategorySerializer < BaseSerializer
          include ResourceSerializerConcern
        end
      end
    end
  end
end
