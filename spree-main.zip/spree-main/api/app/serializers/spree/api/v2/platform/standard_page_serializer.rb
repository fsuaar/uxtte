module Spree
  module Api
    module V2
      module Platform
        class StandardPageSerializer < CmsPageSerializer
          # Place holder serializer for Webhooks.
        end
      end
    end
  end
end
