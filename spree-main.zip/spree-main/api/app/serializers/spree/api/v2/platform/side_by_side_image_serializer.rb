module Spree
  module Api
    module V2
      module Platform
        class SideBySideImageSerializer < CmsSectionSerializer
        end
      end
    end
  end
end
