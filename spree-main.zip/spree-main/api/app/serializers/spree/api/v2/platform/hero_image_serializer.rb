module Spree
  module Api
    module V2
      module Platform
        class HeroImageSerializer < CmsSectionSerializer
        end
      end
    end
  end
end
