require 'spree/core'

module Spree
  module Api
  end
end

require 'spree/api/engine'
