Spree CLI
===============

Command line utility to create new Spree extensions

To build a new Spree Extension, you can run
```ruby
spree extension my_extension
```

This will create a brand new project with all the developer tools and gems needed to developer your extension.
